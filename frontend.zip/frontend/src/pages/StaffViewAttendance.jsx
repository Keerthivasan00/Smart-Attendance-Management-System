import React from 'react'

function StaffViewAttendance() {
  return (
    <div>StaffViewAttendance</div>
  )
}

export default StaffViewAttendance