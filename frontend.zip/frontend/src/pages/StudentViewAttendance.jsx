import React from 'react'

function StudentViewAttendance() {
  return (
    <div>StudentViewAttendance</div>
  )
}

export default StudentViewAttendance