import React from "react";

function GenerateOTP() {
  return <div>Generate OTP Page</div>;
}

export default GenerateOTP; // ✅ default export
