import React from 'react'

function HodAssignStaff() {
  return (
    <div>HodAssignStaff</div>
  )
}

export default HodAssignStaff